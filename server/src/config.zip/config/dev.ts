// dev.js
const devKeys = {
  googleClientID:
    '750072190059-r2roakr3orp17fbnsua9q6ktmi8ptjjl.apps.googleusercontent.com',
  googleClientSecret: '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',
  mongoURI:
    'mongodb+srv://hrushavladyslavwork:4zLLf05FsVcVaE9s@cluster0.cqeqpfa.mongodb.net/',
  cookieKey: 'qY5pF9XsWbJ2Gc4Ae3NzrLmPvDxK7TQV',
  openAIKey: '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',
};

export default devKeys;
